/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This class sets up the actions of the widgets.
 * It sets the popup menu for base currency and the target currency.
 * It allows the conversion switch button to hide or display amount input text.
 * It allows submit button to call methods to send requests to server.
 * After the job completes, results will be displayed below the submit button.
 */

package ds.edu.cmu;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;

import android.view.MenuItem;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Switch;
import android.widget.TableRow;

import android.widget.TextView;
import android.widget.Toast;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ExchangeRateChecker extends AppCompatActivity {

    ExchangeRateChecker me=this; // pointer to the checker
    private Map<String, String> map; // map of the currency names to codes


    /**
     * In this method, we will first set up the view for users to select
     * base currency and target currency, and optionally to type in an amount
     * to convert.
     * The conversion mode will control whether to display the amount input box.
     * The submit button will pack the UI information and call methods.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // initialize the super class
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ExchangeRateChecker ma=this;

        // build the map for popup menu
        try {
            buildCurrencyMap();
        } catch (IOException e) {
            map=new HashMap<>();
            map.put("No currency found","");
        }

        Button base_currency=findViewById(R.id.base_currency);
        Button target_currency=findViewById(R.id.target_currency);

        // set listeners to currency selection buttons
        // display the popup menu
        base_currency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMenu(view);
            }
        });
        target_currency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showMenu(view);
            }
        });

        // set listener to conversion mode
        // control the visibility of amount input box
        @SuppressLint("UseSwitchCompatOrMaterialCode")
        Switch conversion_mode=(Switch) findViewById(R.id.conversion);
        TableRow amount=findViewById(R.id.amount_input);
        conversion_mode.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if(isChecked){
                    amount.setVisibility(View.VISIBLE);
                }else{
                    amount.setVisibility(View.INVISIBLE);
                }
            }
        });

        // set listener to submit button
        // gather information from the UI and call methods
        Button submit=findViewById(R.id.submit);
        TextView result=findViewById(R.id.result);
        EditText amountInput=findViewById(R.id.amount);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // check if the base currency is selected
                if(base_currency.getText().equals("--Select--")){
                    Toast.makeText(ExchangeRateChecker.this, "Missing base currency",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                // check if the target currency is selected
                if(target_currency.getText().equals(R.string.select)){
                    Toast.makeText(ExchangeRateChecker.this, "Missing target currency",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                // check if the amount_input is positive and non-zero
                double amount_input=0;
                if(conversion_mode.isChecked()){
                    if(amountInput.getText().toString().equals("")){
                        Toast.makeText(ExchangeRateChecker.this, "Missing amount",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    amount_input=Double.parseDouble(amountInput.getText().toString());
                    if(amount_input<0){
                        Toast.makeText(ExchangeRateChecker.this, "Invalid amount",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }else if(amount_input==0){
                        Toast.makeText(ExchangeRateChecker.this, "Missing amount",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                }

                // set response visible while doing search on the backend
                result.setVisibility(View.VISIBLE);
                result.setText(R.string.checking);

                //retrieve inputs from interface
                String base_code=map.get(base_currency.getText());
                String target_code=map.get(target_currency.getText());
                // do search on the backend, send requests to server and handle response,
                // and display the results
                GetResult getResult=new GetResult();
                getResult.getResult(base_code,target_code,amount_input,conversion_mode.isChecked(),
                        me,ma);
            }
        });
    }

    /**
     * This method creates menuitems, adds them to menu, and display them at the view position.
     * https://developer.android.com/develop/ui/views/components/menus#PopupMenu
     * @param v Position where the menu will pop up
     */
    private void showMenu(View v){
        PopupMenu popupMenu=new PopupMenu(ExchangeRateChecker.this,v);
        // set up menu items
        for(String key:map.keySet()){
            popupMenu.getMenu().add(key);
        }
        // handle click activities
        // set the button value to the selected items
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                ((Button)v).setText(menuItem.getTitle());
                return true;
            }
        });
        // display the menu
        popupMenu.show();
    }

    /**
     * Parse information from the file to build the map from currency names to codes
     * https://stackoverflow.com/questions/15580111/how-can-i-dynamically-create-menu-items
     * @throws IOException
     */
    private void buildCurrencyMap() throws IOException {
        // read currency name-code pairs from file
        DataInputStream textFileStream = new DataInputStream(getAssets()
                .open(String.format("currencyCodes")));
        Scanner input=new Scanner(textFileStream);
        // write the pairs to map
        map=new HashMap<>();
        while(input.hasNext()){
            String[] pair=input.nextLine().split(",");
            map.put(pair[0],pair[1]);
        }
    }

    /**
     * This routine will display the results and reset inputs in the UI
     * @param response
     */
    public void resultReady(Response response){
        TextView result=findViewById(R.id.result);
        // handle error response
        if(response==null){
            result.setText("Unable to find... Please try again.");
            return;
        }

        // retrieve the full names of currencies selected from UI
        TextView base_curr_view=(TextView)findViewById(R.id.base_currency);
        TextView target_curr_view=(TextView)findViewById(R.id.target_currency);
        String base_currency=base_curr_view.getText().toString();
        String target_currency=target_curr_view.getText().toString();
        String prev_amount=((EditText)findViewById(R.id.amount)).getText().toString();

        // format the result
        StringBuilder sb=new StringBuilder();
        sb.append("Result for "+base_currency+" and "+target_currency+"\n");
        sb.append("Exchange Rate: \n");
        sb.append("          "+response.rate).append("\n");
        sb.append("Last updated time: \n");
        sb.append("          "+response.time_last_update_utc).append("\n");
        if(response.isConversion){
            sb.append(response.base_code+" "+prev_amount+" can be converted to "+
                    response.target_code+" "+response.amount+"\n");
        }

        // pass the result to UI result TextView
        result.setText(sb.toString());

        // reset the UI inputs
        EditText amountInput=findViewById(R.id.amount);
        Switch conversion_mode=(Switch) findViewById(R.id.conversion);
        amountInput.getText().clear();
        base_curr_view.setText(R.string.select);
        target_curr_view.setText(R.string.select);
        conversion_mode.setChecked(false);
    }

}