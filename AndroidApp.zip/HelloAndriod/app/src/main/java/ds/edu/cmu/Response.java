/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * The class stores information parsed from server's messages
 */

package ds.edu.cmu;

public class Response {
    boolean isConversion;
    double rate;
    double amount;
    String time_last_update_utc;
    String base_code;
    String target_code;
}
