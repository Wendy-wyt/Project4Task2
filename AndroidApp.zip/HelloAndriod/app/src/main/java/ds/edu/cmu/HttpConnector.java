/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This class seperates the communication from other activities.
 * This class only sends and receives messages to the server.
 * It makes http requests to server and http responses from server.
 */

package ds.edu.cmu;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class HttpConnector {
    /**
     * Make an HTTP GET request and listened to server's response
     * @param message Message to pass to server
     * @return Plain message from server; null if the request
     */
    public static String doGet(String message) {

        HttpURLConnection conn;
        int status = 0; // status code
        String result=""; // message from server

        try {
            // GET wants us to pass the message on the URL line
            URL url = new URL("https://wendy-wyt-vigilant-telegram-7x5xwg59xxwfwp5-8080.preview.app.github.dev/api/" + message);
//            URL url = new URL("http://10.0.2.2:8080/Project4Task2-1.0-SNAPSHOT/api/" + message);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            // we are sending plain text
            conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
            // tell the server what format we want back
            conn.setRequestProperty("Accept", "text/plain");

            // wait for response
            status = conn.getResponseCode();

            // set http response message - this is just a status message
            // and not the body returned by GET
            result=conn.getResponseMessage();

            if (status == 200) {
                result= getResponseBody(conn);
                Log.i("HttpConnector",result);
            }else{
                Log.i("HttpConnector_Error",result);
                result="";
            }

            conn.disconnect();
        }
        // handle exceptions
        catch (MalformedURLException e) {
            Log.i("HttpConnector","URL Exception thrown" + e);
        } catch (IOException e) {
            Log.i("HttpConnector","IO Exception thrown" + e);
        } catch (Exception e) {
            Log.i("HttpConnector","Exception thrown" + e);
        }
        return result;
    }

    // Gather up a response body from the connection
    // and close the connection.
    public static String getResponseBody(HttpURLConnection conn) {
        String responseText = "";
        try {
            String output = "";
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));
            while ((output = br.readLine()) != null) {
                responseText += output;
            }
            conn.disconnect();
        } catch (IOException e) {
            System.out.println("Exception caught " + e);
        }
        return responseText;
    }
}
