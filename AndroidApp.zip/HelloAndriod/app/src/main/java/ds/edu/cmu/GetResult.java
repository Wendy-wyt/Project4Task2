/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This class provides methods to send requests, receive responses,
 * and display results to the UI.
 * This class will handle tasks in the background without slowing down
 * the foreground.
 */

package ds.edu.cmu;

import android.app.Activity;
import com.google.gson.Gson;

public class GetResult {
    ExchangeRateChecker checker=null; // for callback
    Response response =null; // store response from server
    Request request=null; // store request from user

    /**
     * This method will take input from the checker and then send request to server.
     * After receiving the response, it will start handle the response and display
     * formatted result to the interface. All tasks will be completed in the background.
     * @param base_code Code of base currency
     * @param target_code Code of target currency
     * @param amount Amount to be converted
     * @param isConversion Whether to convert
     * @param activity The UI thread
     * @param checker UI foreground
     */
    public void getResult(String base_code, String target_code,double amount,
                          boolean isConversion, Activity activity, ExchangeRateChecker checker) {
        request=new Request();
        this.checker = checker;
        // store inputs from user to the request message
        request.base_code=base_code;
        request.target_code=target_code;
        request.amount=amount;
        request.isConversion=isConversion;
        // start a thread in background to perform search
        new BackgroundTask(activity).execute();
    }

    /**
     * Perform tasks in the background.
     * The tasks include:
     *   send request to server using JSON
     *   receive request from the server in JSON format
     *   display the result to the User Interface
     */
    private class BackgroundTask {

        private Activity activity; // The UI thread

        // Constructor
        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        /**
         * start a new thread and complete jobs
         */
        private void startBackground() {
            // start a new thread in the background
            new Thread(new Runnable() {
                public void run() {
                    doInBackground();
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        /**
         * start a thread and executing the jobs in the new thread
         */
        private void execute(){
            // There could be more setup here, which is why
            //    startBackground is not called directly
            startBackground();
        }

        // doInBackground( ) implements the search method
        private void doInBackground() {
            response = search(request);
        }

        // onPostExecute( ) will run on the UI thread after the background
        //    thread completes. It will set the formatted result to the UI
        public void onPostExecute() {
            checker.resultReady(response);
        }

        /**
         * This routine sends request to server and receive response with search results
         * @param request The request object with information
         * @return The response with message; null if the connection is failed
         */
        private Response search(Request request) {
            // prepare the message to server
            Gson gson=new Gson();
            String message= gson.toJson(request);
            Response httpResponse=null;
            // send messages to server and receive result from server
            String result= "";
            result = HttpConnector.doGet(message);
            // handle successful connection and results
            if(!result.equals("")){
                // parse the result message to a response object
                httpResponse=gson.fromJson(result,Response.class);
            }
            return httpResponse;
        }
    }
}
