/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edi)
 * This class stores information to parse to request messages
 */

package ds.edu.cmu;

public class Request {
    String base_code,target_code;
    Double amount;
    boolean isConversion;
}
