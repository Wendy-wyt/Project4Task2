/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This class sets up the connection to MongoDB database. It provides basic operations:
 *     insertDoc(): add information to collection
 *     Analytics: methods to generate analytics for operations analysis
 *         getPeak(): get the document with the most occurrence
 *         db_toString(): get all the documents
 *         getTodayCount(): get the count of today's requests
 *         getCurrCodes(): get all the currency codes used in previous requests
 *     clear(): clear all documents in the collection
 */

import com.google.gson.Gson;
import com.mongodb.*;
import com.mongodb.client.*;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class ExRateMongoDB {
    static MongoDatabase database;
    String collName="task2"; // collection's name

    /**
     * Constructor: set up connections
     */
    public ExRateMongoDB(){
        setMongoDB();
    }

    /**
     * Set up connections to the database
     */
    private void setMongoDB(){
        ConnectionString connectionString = new ConnectionString("mongodb://yutingwu:LBIJ6VLPm7z1sA7b@" +
                "ac-itetvwv-shard-00-02.ggwtpnj.mongodb.net:27017," + // cluster url
                "ac-itetvwv-shard-00-01.ggwtpnj.mongodb.net:27017," + // cluster url
                "ac-itetvwv-shard-00-00.ggwtpnj.mongodb.net:27017" + // cluster url
                "/project4task1?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        database = mongoClient.getDatabase("Project4Task1");
    }

    /**
     * Take the input with key-value pairs and write it to a new document
     * @param input Formatted input of content for document
     * @return 1 if the storage is successful; 0 if the storage fails
     * https://www.mongodb.com/docs/drivers/java/sync/v4.3/fundamentals/crud/query-document/
     */
    public int insertDoc(String input){
        // find the target collection
        MongoCollection collection=null;
        try{
            collection=database.getCollection(collName);
        }catch(IllegalArgumentException e){
            database.createCollection(collName);
            collection=database.getCollection(collName);
        }

        Document doc=new Document(); // new document to be inserted
        // parse input to the document
        String pairs[]=input.replaceAll("[{}]","").split(",");
        for(String pair: pairs){
            // extract fieldname and key
            String cleanPair=pair.replaceAll("\"","").trim();
            String key=cleanPair.split(":")[0].trim();
            int startofvalue=cleanPair.indexOf(":")+1;
            String value=cleanPair.substring(startofvalue).trim();
            doc.append(key,value);
        }
        // add the record time to the document
        LocalDateTime now=LocalDateTime.now();
        doc.append("record_hour",now.getHour());
        doc.append("record_month_date",now.getDayOfMonth());
        doc.append("record_month",now.getMonthValue());

        // add the document to collection
        try{
            collection.insertOne(doc);
        }catch(MongoWriteException e){
            System.out.println(e.getMessage());
            return 0;
        }catch(MongoWriteConcernException e){
            System.out.println(e.getMessage());
            return 0;
        }catch(MongoException e){
            System.out.println(e.getMessage());
            return 0;
        }
        return 1;
    }

    /**
     * @return All documents in the collection
     * https://www.mongodb.com/docs/drivers/java/sync/v4.3/fundamentals/crud/query-document/
     */
    public String db_toString(){
        StringBuilder sb=new StringBuilder();
        // locate the collection
        MongoCollection collection;
        try{
            collection=database.getCollection(collName);
        }catch(IllegalArgumentException e){
            return sb.toString();
        }
        // iterate all documents and add their JSON to the result
        MongoCursor<Document> cursor=collection.find().iterator();
        try {
            while(cursor.hasNext()) {
                sb.append(cursor.next().toJson()).append("\n");
            }
        } finally {
            cursor.close();
        }
        return sb.toString();
    }

    /**
     * This routine returns the value with the most occurrences of a specified field.
     * @param fieldname Field to group and count
     * @return Value with the most occurrences and the count
     * https://www.mongodb.com/docs/drivers/java/sync/v4.3/fundamentals/crud/query-document/
     */
    public List<String> getPeak(String fieldname){
        List<String> result = new ArrayList<>();
        // locate the collection
        MongoCollection collection=null;
        try{
            collection=database.getCollection(collName);
        }catch(IllegalArgumentException e){
            return result;
        }

        AtomicInteger max= new AtomicInteger(); // Maximum occurrence so far
        collection.aggregate(
                Arrays.asList(
                        Aggregates.group("$"+fieldname, Accumulators.sum("count", 1))
                )
        ).forEach(doc -> {
            if(doc==null) return;
            String docStr=((Document)doc).toJson().replaceAll("[\"{}]","");
            int count=Integer.parseInt(docStr.split(",")[1].split(":")[1].trim());
            // replace the previous doc with the doc of the greatest count
            if(count> max.get()){
                result.clear();
                result.add(docStr);
                max.set(count);
            // add the new doc with the equally greatest count
            }else if(count== max.get()){
                result.add(docStr);
            }
        });
        return result;
    }

    /**
     * @return Count of all requests handled today
     * https://www.mongodb.com/docs/drivers/java/sync/v4.3/fundamentals/crud/query-document/
     */
    public long getTodayCount(){
        long result=0;
        // locate the collection
        MongoCollection collection=null;
        try{
            collection=database.getCollection(collName);
        }catch(IllegalArgumentException e){
            return result;
        }
        // filter the documents with the same date and month
        LocalDateTime now=LocalDateTime.now();
        Bson filter =Filters.and(Filters.eq(
                "record_month_date",now.getDayOfMonth()),
                Filters.eq("record_month", now.getMonthValue()));
        result = collection.countDocuments(filter);
        return result;
    }

    /**
     * @return All currency codes searched in all previous requests
     * Note: The currency codes are repetitive
     * https://www.mongodb.com/docs/drivers/java/sync/v4.3/fundamentals/crud/query-document/
     */
    public List<String> getCurrCodes(){
        List<String> result=new ArrayList<>();
        // locate the collection
        MongoCollection collection=null;
        try{
            collection=database.getCollection(collName);
        }catch(IllegalArgumentException e){
            return result;
        }

        // retrieve all values of "base_code" and "target_code"
        Bson filter = Filters.empty();
        Bson projection = Projections.fields(
                Projections.include("base_code","target_code"),
                Projections.excludeId());
        collection.find(filter).projection(projection)
                .forEach(doc -> {
                    String docStr=((Document)doc).toJson().replaceAll("[\"{}]","");
                    String base=docStr.split(",")[0].split(":")[1];
                    String target=docStr.split(",")[1].split(":")[1];
                    result.add(base);
                    result.add(target);
                });
        return result;
    }

    /**
     * Clear all documents in the collection
     */
    public void clear(){
        // locate collection
        MongoCollection collection=null;
        try{
            collection=database.getCollection(collName);
        }catch(IllegalArgumentException e){
            return;
        }
        Bson filter=Filters.empty();
        collection.deleteMany(filter);
    }
}
