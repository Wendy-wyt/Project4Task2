/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This class stores the information from the users for searching.
 */

public class Request {
    String base_code,target_code;
    double amount;
    boolean isConversion;
}
