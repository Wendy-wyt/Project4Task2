/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This servlet handles requests from mobile apps and the web server.
 * The requests from mobile apps to get the exchange rate or the conversion amount will
 *     call methods to request the results from the third API. And then, the results
 *     will be sent to mobile apps. At the same time, all successful requests will be
 *     recorded into MongoDB database.
 * The dashboard requests will call methods to generate analysis and push the results
 *     to the new user interface. It then sends users to the updated page. The dashboard
 *     will not update automatically.
 */

import com.google.gson.Gson;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;

/**
 * Receive request from path /api and /dashboard
 */
@WebServlet(name = "ExRateServlet",value = {"/api/*","/dashboard"})
public class Servlet extends HttpServlet {

    static final ExRateModel model=new ExRateModel();
    public void init() {}

    /**
     * This routine handles GET requests.
     * Based on the request messages, it either searches for the result or deployes
     *     the new dashboard results.
     * @param request request with messages and path information
     * @param response response with messages
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action=request.getServletPath(); // action of the request

        // prepare the appropriate DOCTYPE (mobile or website) for the view pages
        String ua = request.getHeader("User-Agent");
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            request.setAttribute("doctype",
                    "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" " +
                            "\"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            request.setAttribute("doctype",
                    "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" " +
                            "\"http://www.w3.org/TR/html4/loose.dtd\">");
        }
        String nextView="index.jsp";

        // call methods to retrieve results from third-party API
        if(action.contains("/api")){
            String requestMsg=request.getPathInfo()
                    .replace("/",""); // request message with all necessary info
            String responseMsg=getExRate(requestMsg,response); // response message with answers
            // write message to the response and send to users
            response.getWriter().write(responseMsg);
            response.getWriter().flush();
        // call methods to regenerate the analytics
        }else if(action.contains("/dashboard")){
            nextView=renderDashboard(request);
            // forward the next view to user interface
            RequestDispatcher view = request.getRequestDispatcher(nextView);
            view.forward(request, response);
        }
    }

    /**
     * The routine calls methods to generate analysis results.
     * The analysis include: Top 5 searched currencies, Peak time of receiving requests,
     *     and Total requests received today.
     * The analysis also display all data from database.
     * @param request request with messages and path information
     * @return Next view with updated analysis
     */
    private static String renderDashboard(HttpServletRequest request){
        // get operations analytics
        request.setAttribute("top5currencies",model.getTopCurrency(5));
        request.setAttribute("peakAnalysis",model.getPeakAnalysis());
        request.setAttribute("sumToday",model.getTodayCount());

        // get full logs
        request.setAttribute("fullLogs",model.getFullLogs());

        // pass the next view
        String nextView="dashboard.jsp";
        return nextView;
    }

    /**
     * This routine calls methods from the model and gets results.
     * @param requestMsg Message in request
     * @param response HttpServletResponse to users
     * @return formatted String for response
     */
    private static String getExRate(String requestMsg,HttpServletResponse response){
        String message=null;

        // parse the JSON representation of requests to a Request object
        Gson gson=new Gson();
        Request requestObj=gson.fromJson(requestMsg,Request.class);
        // check if the request needs to convert an amount
        if(requestObj.isConversion){
            // call methods from ExRateModel
            ExRate result=model.searchExRateWithAmount(requestObj.base_code,
                    requestObj.target_code, requestObj.amount);
            // check if the search is successful
            if(result!=null){
                Response responseObj=exRateToResponse(result);
                responseObj.isConversion=true;
                message=gson.toJson(responseObj);
                response.setStatus(200);
            }else{
                response.setStatus(404);
            }
        }else{
            // call methods from ExRateModel
            ExRate result= model.searchExRate(requestObj.base_code, requestObj.target_code);
            // check if the search is successful
            if(result!=null){
                Response responseObj=exRateToResponse(result);
                responseObj.isConversion=false;
                message=gson.toJson(responseObj);
                response.setStatus(200);
            }else{
                response.setStatus(404);
            }
        }
        return message;
    }

    /**
     * This helper method transfers the search result to a response object.
     * @param exRate Search result from 3rd party api
     * @return Response object with proper information
     */
    private static Response exRateToResponse(ExRate exRate){
        Response response=new Response();
        response.rate=exRate.conversion_rate;
        response.amount=exRate.conversion_result;
        response.base_code= exRate.base_code;
        response.target_code= exRate.target_code;
        response.time_last_update_utc= exRate.time_last_update_utc;
        return response;
    }
}
