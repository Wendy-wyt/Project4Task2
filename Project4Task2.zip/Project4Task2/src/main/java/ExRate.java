/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This class stores the full information from 3rd party API.
 * It also provides methods to parse datetime in utc to formatted datetime string.
 * Serialization: time_last_update_utc,base_code,target_code,conversion_rate,
 *     conversion_result;
 * Deserialization: result,time_last_update_utc,time_last_update_unix,base_code,
 *     target_code,conversion_rate,conversion_result
 */

import com.google.gson.annotations.Expose;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class ExRate {
    @Expose(serialize = false,deserialize = true)
    String result;
    @Expose(serialize = true,deserialize = true)
    String time_last_update_utc;
    @Expose(serialize = false,deserialize = true)
    String time_last_update_unix;
    @Expose(serialize = true,deserialize = true)
    String base_code,target_code;
    @Expose(serialize = true,deserialize = true)
    double conversion_rate,conversion_result;
    @Expose(serialize = false,deserialize = false)
    LocalDateTime last_update_dateTime;

    /**
     * This routine helps parse timestamp in unix format to formatted datetime,
     * and replace the old time_last_update_utc
     */
    public void parseDateTime(){
        last_update_dateTime = LocalDateTime.ofEpochSecond(
                Long.parseLong(time_last_update_unix), 0, ZoneOffset.UTC);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss", Locale.ENGLISH);
        time_last_update_utc=last_update_dateTime.format(formatter);
    }
}
