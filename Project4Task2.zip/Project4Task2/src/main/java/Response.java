/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This class stores information for HttpServletResponse sent to users.
 */

public class Response {
    boolean isConversion;
    double rate;
    double amount;
    String time_last_update_utc;
    String base_code;
    String target_code;
}
