/**
 * @author Yuting Wu (yutingwu@andrew.cmu.edu)
 * This class serves as the model with functions that the servlet can call to fulfill requests.
 * searchExRate() and searchExRate() send requests to the third party API and parse the response
 *     and record data to database.
 * It also provides methods to fulfill the analytics requirement.
 * It further provides a method to display all documents.
 */

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

public class ExRateModel {
    private static final String APIKEY="70f01b22d6fc666eb77cf181"; // Third-party API key
    private static final ExRateMongoDB db=new ExRateMongoDB(); // Database

    /**
     * This routine will search for the exchange rate from the base currency
     * to the target currency.
     *
     * pre-condition: Since users can only pick inputs from the standard inputs,
     *                this program will not check the parameters.
     *
     * @param base Base currency code
     * @param target Target currency code
     * @return ExRate if success; null if the request fails
     */
    public ExRate searchExRate(String base, String target){
        ExRate result=null;
        // read from url and receive the response in json
        String url="https://v6.exchangerate-api.com/v6/"+APIKEY+"/pair/"+base+"/"+target;
        String jsonStr=fetch(url);
        // if the request fails, return -1 error code
        if(Objects.equals(jsonStr, "")) return result;
        // convert the json string to json object
        Gson gson=new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
        result=gson.fromJson(jsonStr, ExRate.class);
        result.parseDateTime();

        // record data to database
        recordJobData(result);
        return result;
    }

    /**
     * This routine will return the amount in the target currency converted from
     * the base currency.
     *
     * pre-condition: amount must not be negative;
     *                Since users can only pick inputs from the standard inputs,
     *                this program will not check the parameters.
     *
     * @param base Base currency code
     * @param target Target currency code
     * @param amount Converted amount in the target currency
     * @return ExRate if success; null if the request fails
     */
    public ExRate searchExRateWithAmount(String base, String target, double amount){
        ExRate result=null;
        // read from url and receive the response in json
        String url="https://v6.exchangerate-api.com/v6/"+APIKEY+"/pair/"+base+"/"+target+"/"+amount;
        String jsonStr=fetch(url);
        // If the request fails, return null
        if(Objects.equals(jsonStr, "")) return result;
        // convert the json string to ExRate object
        Gson gson=new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
        result=gson.fromJson(jsonStr, ExRate.class);
        result.parseDateTime();

        // record data to database
        recordJobData(result);
        return result;
    }

    /**
     * Read the url and return a string of all the html elements
     * @param urlString the url needed to be opened
     * @return the string of the response
     */
    private String fetch(String urlString) {
        StringBuilder response = new StringBuilder();
        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response.append(str);
            }
            in.close();
        } catch (IOException e) {
            System.out.println("IOException: "+e.getMessage());
            response = new StringBuilder().append("");
        }
        return response.toString();
    }

    /**
     * Call methods to store data to database
     * @param result ExRate object with information needed
     * @return 1 if successful; 0 if failed
     */
    private int recordJobData(ExRate result){
        // prepare message in JSON to store in mongoDB
        Gson gson=new GsonBuilder().excludeFieldsWithoutExposeAnnotation().create();
        StringBuilder sb=new StringBuilder();
        sb.append(gson.toJson(result));
        return db.insertDoc(sb.toString());
    }

    /**
     * Convert the data retrieved from database into table in HTML format
     * @return All data from database in HTML format
     */
    public String getFullLogs(){
        HashMap<String, List<String>> formatted=new HashMap<>(); // values grouped by fieldname
        ArrayList<String> keys=new ArrayList<>(); // all fieldname

        // retrieve full logs from Database
        String dbStr=db.db_toString();
        if(dbStr==""||dbStr==null){
            return "";
        }

        // group data by fields
        String raws[]=dbStr.split("\n");
        for(String raw:raws){
            // clear the raw logs and prepare for the formatting
            String pairs[]=raw.replaceAll("[\"{}]","").split(",");
            for(String pair:pairs){
                String splited[]=pair.split(":");
                String key=splited[0].trim();
                int startofvalue=pair.indexOf(":")+1;
                String value=pair.substring(startofvalue).trim();
                if(!formatted.containsKey(key)){
                    keys.add(key);
                    formatted.put(key,new ArrayList<>());
                }
                formatted.get(key).add(value);
            }
        }

        // format data in HTML table
        StringBuilder sb=new StringBuilder();
        sb.append("<table>");
        // format all fieldnames
        sb.append("<tr>");
        for(String key:keys){
            sb.append("<td>").append(key).append("</td>");
        }
        sb.append("</tr>");
        // format all values
        for(int i=0; i<formatted.get(keys.get(0)).size();i++){
            sb.append("<tr>");
            for(String key:keys){
                sb.append("<td>").append(formatted.get(key).get(i)).append("</td>");
            }
            sb.append("</tr>");
        }
        sb.append("</table>"); // end of table
        return sb.toString();
    }

    /**
     * Generate analysis for peak time in hour, date of month, and month
     * @return Analysis of peak time
     */
    public String getPeakAnalysis(){
        StringBuilder sb=new StringBuilder();

        // Get peak hour of day
        List<String> peakHours=db.getPeak("record_hour");
        sb.append("Peak Hour of Day--Hour(Count)").append("<br>");
        for(String peakHour:peakHours){
            String count=peakHour.split(",")[1].split(":")[1];
            String hour=peakHour.split(",")[0].split(":")[1];
            sb.append(String.format("%s(%s)",hour,count)).append("<br>");
        }
        // Get peak date of month
        List<String> peakMonthDates=db.getPeak("record_month_date");
        sb.append("Peak Date of Month--Date(Count)").append("<br>");
        for(String peakWeepeakMonthDate:peakMonthDates){
            String count=peakWeepeakMonthDate.split(",")[1].split(":")[1];
            String date=peakWeepeakMonthDate.split(",")[0].split(":")[1];
            sb.append(String.format("%s(%s)",date,count)).append("<br>");
        }
        // Get peak month
        List<String> peakMonths=db.getPeak("record_month");
        sb.append("Peak Month--Month(Count)").append("<br>");
        for(String peakMonth:peakMonths){
            String count=peakMonth.split(",")[1].split(":")[1];
            String month=peakMonth.split(",")[0].split(":")[1];
            sb.append(String.format("%s(%s)",month,count)).append("<br>");
        }
        return sb.toString();
    }

    /**
     * @return Total requests completed today
     */
    public String getTodayCount(){
        return "Server has completed " + db.getTodayCount() + " requests" + "<br>";
    }

    /**
     * @param n Number of currencies returned
     * @return Top n most searched currencies
     */
    public String getTopCurrency(int n){
        StringBuilder sb=new StringBuilder();

        /**
         * Simple class for code and the corresponding count
         */
        class CodeCount implements Comparable<CodeCount>{
            String code;
            int count;

            @Override
            public int compareTo(CodeCount o) {
                return o.count-this.count;
            }
        }

        List<String> codes=db.getCurrCodes();
        // map all codes with their counts
        HashMap<String, CodeCount> map=new HashMap<>();
        for(String code:codes){
            if(!map.containsKey(code)){
                CodeCount node=new CodeCount();
                node.code=code;
                node.count=0;
                map.put(code, node);
            }
            map.get(code).count++;
        }

        // sort the codes by counts
        PriorityQueue<CodeCount> maxHeap=new PriorityQueue<>();
        for(CodeCount node:map.values()){
            maxHeap.add(node);
        }

        // retrieve the top n codes
        for(int i=0;i<n&&i<map.size(); i++){
            CodeCount node=maxHeap.poll();
            sb.append(String.format("%s(%s)",node.code,node.count)).append("<br>");
        }

        return sb.toString();
    }
}
